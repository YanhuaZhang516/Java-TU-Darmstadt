package v5;

import fopbot.*;

public class Square {

	public static void main(String[] args) {
		World.setSize(10, 10);
		World.setDelay(100);
		World.setVisible(true);

		// TODO: V5 insert your code here

	}

}