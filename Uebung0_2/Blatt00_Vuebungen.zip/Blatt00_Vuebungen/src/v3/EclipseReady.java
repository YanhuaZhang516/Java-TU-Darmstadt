package v3;
public class EclipseReady {

	public static void main(String[] args) {
		String properties[] = { "java.home", "java.version", "java.runtime.version" };

		for (String p : properties) {
			System.out.println(p + " = " + System.getProperty(p));
		}
	}

}