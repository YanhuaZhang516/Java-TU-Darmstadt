package chesspieces;

import fopbot.World;
import main.CUtils;
import main.ChessColor;

import java.awt.Point;

public class Knight extends ChessPiece {

	public Knight(int x, int y, ChessColor color) {
		super(x, y, color);

		if (color == ChessColor.BLACK) {
			setImageId("knight_black");
		} else {
			setImageId("knight_white");
		}
	}

	private Point[] getFields(boolean attack) {
		int fieldsFound = 0;
		int fieldIndex = 0;

		Point[] possibleFields = null;

		for (int a = 0; a < 2; a++) {

			for (int i = -2; i < 3; i++) {
				for (int j = -2; j < 3; j++) {
					if (i >= -1 && i <= 1 && j >= -1 && j <= 1) {
						continue;
					}
					if (i == 0 || j == 0 || CUtils.abs(i) == CUtils.abs(j)) {
						continue;
					}

					Point pos = new Point(getX() + i, getY() + j);

					if (pos.x < 0 || pos.y < 0 || pos.x >= World.getWidth() || pos.y >= World.getHeight()) {
						// do not check fields out of bounds
						continue;
					}

					boolean validField = false;

					boolean enemyPieceOnField = CUtils.isChessPieceWithColorInField(pos.x, pos.y,
							CUtils.getOtherColor(getColor()));

					if (attack) {
						if (enemyPieceOnField == true) {
							validField = true;
						}
					} else {
						boolean ownPieceOnField = CUtils.isChessPieceWithColorInField(pos.x, pos.y, getColor());
						if (enemyPieceOnField == false && ownPieceOnField == false) {
							validField = true;
						}
					}

					if (validField) {
						if (a == 0) {
							fieldsFound++;
						} else {

							if (possibleFields == null) {
								if (fieldsFound == 0) {
									return null;
								}
								possibleFields = new Point[fieldsFound];
							}

							possibleFields[fieldIndex] = pos;
							fieldIndex++;
						}
					}
				}
			}
		}
		return possibleFields;
	}

	@Override
	public Point[] getMoveFields() {
		// TODO: H6
		return getFields(false);
	}

	@Override
	public Point[] getAttackFields() {
		// TODO: H6
		return getFields(true);
	}

}
