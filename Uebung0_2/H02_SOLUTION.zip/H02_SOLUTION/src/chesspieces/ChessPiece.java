package chesspieces;

import java.awt.Point;

import fopbot.Robot;
import main.ChessColor;

public abstract class ChessPiece extends Robot {

	private ChessColor color;

	/**
	 * Creates a new chess piece given its position and color
	 * 
	 * @param x
	 * @param y
	 * @param color
	 */
	public ChessPiece(int x, int y, ChessColor color) {
		super(x, y);
		this.color = color;
	}

	/**
	 * @return color of the chess piece
	 */
	public ChessColor getColor() {
		return color;
	}

	/**
	 * @return all fields the piece is able to move to according to the game rules
	 */
	public abstract Point[] getMoveFields();

	/**
	 * @return all fields the piece is able to attack according to the game rules
	 */
	public abstract Point[] getAttackFields();

}
