package chesspieces;

import fopbot.World;
import main.CUtils;
import main.ChessColor;

import java.awt.Point;

public class Bishop extends ChessPiece {

	public Bishop(int x, int y, ChessColor color) {
		super(x, y, color);

		if (color == ChessColor.BLACK) {
			setImageId("bishop_black");
		} else {
			setImageId("bishop_white");
		}
	}

	private Point[] getFields(boolean attack) {
		int fieldsFound = 0;
		int fieldIndex = 0;

		Point[] possibleFields = null;

		for (int a = 0; a < 2; a++) {

			for (int i = 0; i < 4; i++)
				for (int j = 1; j < 8; j++) {
					Point pos = null;

					if (i == 0) {
						pos = new Point(getX() + j, getY() + j);
					}

					if (i == 1) {
						pos = new Point(getX() - j, getY() - j);
					}

					if (i == 2) {
						pos = new Point(getX() + j, getY() - j);
					}

					if (i == 3) {
						pos = new Point(getX() - j, getY() + j);
					}

					if (pos.x < 0 || pos.y < 0 || pos.x >= World.getWidth() || pos.y >= World.getHeight()) {
						// do not check fields out of bounds
						continue;
					}

					boolean validField = false;

					boolean enemyPieceOnField = CUtils.isChessPieceWithColorInField(pos.x, pos.y,
							CUtils.getOtherColor(getColor()));
					boolean ownPieceOnField = CUtils.isChessPieceWithColorInField(pos.x, pos.y, getColor());

					if (attack) {
						if (enemyPieceOnField == true) {
							validField = true;
						}
					} else {
						if (enemyPieceOnField == false && ownPieceOnField == false) {
							validField = true;
						}
					}

					if (validField) {
						if (a == 0) {
							fieldsFound++;
						} else {

							if (possibleFields == null) {
								if (fieldsFound == 0) {
									return null;
								}
								possibleFields = new Point[fieldsFound];
							}

							possibleFields[fieldIndex] = pos;
							fieldIndex++;
						}

						if (attack) {
							// attackable unit in current direction found so break
							break;
						}
					} else {
						if (attack == false) {
							break;
						} else {
							if (ownPieceOnField) {
								// path in current direction blocked so break
								break;
							}
						}
					}

				}

		}
		return possibleFields;
	}

	@Override
	public Point[] getMoveFields() {
		// TODO: H3
		return getFields(false);
	}

	@Override
	public Point[] getAttackFields() {
		// TODO: H3
		return getFields(true);
	}

}
