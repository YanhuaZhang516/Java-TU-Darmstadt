package chesspieces;

import fopbot.World;
import main.CUtils;
import main.ChessColor;

import java.awt.Point;

public class Pawn extends ChessPiece {

	public Pawn(int x, int y, ChessColor color) {
		super(x, y, color);
		if (color == ChessColor.BLACK) {
			setImageId("pawn_black");
		} else {
			setImageId("pawn_white");
		}
	}

	@Override
	public Point[] getMoveFields() {
		// TODO: H1
		int fieldsFound = 0;
		int fieldIndex = 0;

		Point[] possibleFields = null;

		for (int a = 0; a < 2; a++) {

			// caluclate possible steps to move forward
			// 2 if on start position, 1 otherwise
			int pawnStartY = 1;
			if (getColor() == ChessColor.BLACK) {
				pawnStartY = 6;
			}
			int maxSteps = 1;
			if (getY() == pawnStartY) {
				maxSteps++;
			}
			//

			for (int i = 1; i <= maxSteps; i++) {
				int y = getY();
				if (getColor() == ChessColor.BLACK) {
					y = y - i;
				} else {
					y = y + i;
				}

				Point pos = new Point(getX(), y);

				if (pos.x < 0 || pos.y < 0 || pos.x >= World.getWidth() || pos.y >= World.getHeight()) {
					// do not check fields out of bounds
					continue;
				}

				boolean validField = false;
				boolean enemyPieceOnField = CUtils.isChessPieceWithColorInField(pos.x, pos.y,
						CUtils.getOtherColor(getColor()));
				boolean ownPieceOnField = CUtils.isChessPieceWithColorInField(pos.x, pos.y, getColor());
				if (enemyPieceOnField == false && ownPieceOnField == false) {
					validField = true;
				}

				if (validField && i == 2 && fieldsFound == 0) {
					// first fields is blocked, so it is not possible to move to the second field
					continue;
				}
				if (validField) {
					if (a == 0) {
						fieldsFound++;
					} else {
						if (possibleFields == null) {
							if (fieldsFound == 0) {
								return null;
							}
							possibleFields = new Point[fieldsFound];
						}

						possibleFields[fieldIndex] = pos;
						fieldIndex++;
					}
				}
			}
		}
		return possibleFields;
	}

	@Override
	public Point[] getAttackFields() {
		// TODO: H1
		Point[] possibleFields = null;

		Point pos1 = new Point(getX() - 1, getY() + 1);
		Point pos2 = new Point(getX() + 1, getY() + 1);
		if (getColor() == ChessColor.BLACK) {
			pos1 = new Point(getX() - 1, getY() - 1);
			pos2 = new Point(getX() + 1, getY() - 1);
		}
		boolean enemyPieceOnField1 = false;
		boolean enemyPieceOnField2 = false;

		if (pos1.x >= 0 && pos1.y >= 0 && pos1.x < World.getWidth() && pos1.y < World.getHeight()) {
			enemyPieceOnField1 = CUtils.isChessPieceWithColorInField(pos1.x, pos1.y, CUtils.getOtherColor(getColor()));
		}

		if (pos2.x >= 0 && pos2.y >= 0 && pos2.x < World.getWidth() && pos2.y < World.getHeight()) {
			enemyPieceOnField2 = CUtils.isChessPieceWithColorInField(pos2.x, pos2.y, CUtils.getOtherColor(getColor()));
		}

		if (enemyPieceOnField1 && enemyPieceOnField2) {
			possibleFields = new Point[2];
			possibleFields[0] = pos1;
			possibleFields[1] = pos2;
		} else {
			if (enemyPieceOnField1 == false && enemyPieceOnField2 == false) {
				return null;
			}

			possibleFields = new Point[1];
			if (enemyPieceOnField1) {
				possibleFields[0] = pos1;
			} else {
				possibleFields[0] = pos2;
			}
		}
		return possibleFields;
	}
}
