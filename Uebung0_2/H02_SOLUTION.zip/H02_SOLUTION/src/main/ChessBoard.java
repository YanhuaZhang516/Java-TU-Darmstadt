package main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import chesspieces.Bishop;
import chesspieces.ChessPiece;
import chesspieces.King;
import chesspieces.Knight;
import chesspieces.Pawn;
import chesspieces.Queen;
import chesspieces.Rook;
import fopbot.World;

public class ChessBoard {

	private static ChessPiece[] chessPieces;

	public static void main(String[] args) {
		World.setSize(8, 8);
		World.setDelay(0);

		World.getGlobalWorld().setGuiPanel(new GuiChessPanel(World.getGlobalWorld()));
		loadChessImages();
		initChessPieces();

		World.setDelay(100);

		World.setVisible(true);

	}

	public static ChessPiece[] getAllChessPieces() {
		List<ChessPiece> l = Arrays.asList(chessPieces);
		Collections.shuffle(l);
		return l.toArray(chessPieces);
	}

	public static void initChessPieces() {
		chessPieces = new ChessPiece[32];
		// place pawns
		for (int i = 0; i < 8; i++) {
			Pawn w = new Pawn(i, 1, ChessColor.WHITE);
			Pawn b = new Pawn(i, 6, ChessColor.BLACK);
			chessPieces[i] = w;
			chessPieces[i + 16] = b;
		}
		chessPieces[8] = new Rook(0, 0, ChessColor.WHITE);
		chessPieces[9] = new Knight(1, 0, ChessColor.WHITE);
		chessPieces[10] = new Bishop(2, 0, ChessColor.WHITE);
		chessPieces[11] = new Queen(3, 0, ChessColor.WHITE);
		chessPieces[12] = new King(4, 0, ChessColor.WHITE);
		chessPieces[13] = new Bishop(5, 0, ChessColor.WHITE);
		chessPieces[14] = new Knight(6, 0, ChessColor.WHITE);
		chessPieces[15] = new Rook(7, 0, ChessColor.WHITE);

		chessPieces[24] = new Rook(0, 7, ChessColor.BLACK);
		chessPieces[25] = new Knight(1, 7, ChessColor.BLACK);
		chessPieces[26] = new Bishop(2, 7, ChessColor.BLACK);
		chessPieces[27] = new Queen(3, 7, ChessColor.BLACK);
		chessPieces[28] = new King(4, 7, ChessColor.BLACK);
		chessPieces[29] = new Bishop(5, 7, ChessColor.BLACK);
		chessPieces[30] = new Knight(6, 7, ChessColor.BLACK);
		chessPieces[31] = new Rook(7, 7, ChessColor.BLACK);
	}

	public static void loadChessImages() {
		try {
			World.getGlobalWorld().setAndLoadRobotImagesById("pawn_black",
					new FileInputStream(new File("res/pawn_black.png")),
					new FileInputStream(new File("res/pawn_black.png")), 0, 0);
			World.getGlobalWorld().setAndLoadRobotImagesById("pawn_white",
					new FileInputStream(new File("res/pawn_white.png")),
					new FileInputStream(new File("res/pawn_white.png")), 0, 0);

			World.getGlobalWorld().setAndLoadRobotImagesById("king_black",
					new FileInputStream(new File("res/king_black.png")),
					new FileInputStream(new File("res/king_black.png")), 0, 0);
			World.getGlobalWorld().setAndLoadRobotImagesById("king_white",
					new FileInputStream(new File("res/king_white.png")),
					new FileInputStream(new File("res/king_white.png")), 0, 0);

			World.getGlobalWorld().setAndLoadRobotImagesById("knight_black",
					new FileInputStream(new File("res/knight_black.png")),
					new FileInputStream(new File("res/knight_black.png")), 0, 0);
			World.getGlobalWorld().setAndLoadRobotImagesById("knight_white",
					new FileInputStream(new File("res/knight_white.png")),
					new FileInputStream(new File("res/knight_white.png")), 0, 0);

			World.getGlobalWorld().setAndLoadRobotImagesById("rook_black",
					new FileInputStream(new File("res/rook_black.png")),
					new FileInputStream(new File("res/rook_black.png")), 0, 0);
			World.getGlobalWorld().setAndLoadRobotImagesById("rook_white",
					new FileInputStream(new File("res/rook_white.png")),
					new FileInputStream(new File("res/rook_white.png")), 0, 0);

			World.getGlobalWorld().setAndLoadRobotImagesById("bishop_black",
					new FileInputStream(new File("res/bishop_black.png")),
					new FileInputStream(new File("res/bishop_black.png")), 0, 0);
			World.getGlobalWorld().setAndLoadRobotImagesById("bishop_white",
					new FileInputStream(new File("res/bishop_white.png")),
					new FileInputStream(new File("res/bishop_white.png")), 0, 0);

			World.getGlobalWorld().setAndLoadRobotImagesById("queen_black",
					new FileInputStream(new File("res/queen_black.png")),
					new FileInputStream(new File("res/queen_black.png")), 0, 0);
			World.getGlobalWorld().setAndLoadRobotImagesById("queen_white",
					new FileInputStream(new File("res/queen_white.png")),
					new FileInputStream(new File("res/queen_white.png")), 0, 0);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}
