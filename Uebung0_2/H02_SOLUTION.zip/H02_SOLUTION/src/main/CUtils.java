
package main;

import chesspieces.ChessPiece;
import fopbot.World;

public class CUtils {

	/**
	 * @param x
	 * @param y
	 * @param color
	 * @return true if a chess piece with the given color is in the given field
	 *         (x,y)
	 */
	public static boolean isChessPieceWithColorInField(int x, int y, ChessColor color) {
		if (x < 0 || y < 0 || x >= World.getWidth() || y >= World.getHeight()) {
			System.err.println("x,y out of bounds!");
			System.err.println("x,y out of bounds!");
			return false;
		}

		ChessPiece[] chessPieces = ChessBoard.getAllChessPieces();
		for (ChessPiece cp : chessPieces) {
			if (cp == null || cp.isTurnedOff()) {
				continue;
			}
			if (cp.getX() == x && cp.getY() == y && cp.getColor() == color) {
				return true;
			}
		}

		return false;
	}

	/**
	 * @param color
	 * @return WHITE if given BLACK and the other way around
	 */
	public static ChessColor getOtherColor(ChessColor color) {
		if (color == ChessColor.WHITE) {
			return ChessColor.BLACK;
		} else {
			return ChessColor.WHITE;
		}
	}
	/**
	 * @param n
	 * @return abs(n)
	 */
	public static int abs(int n) {
		if (n < 0) {
			return n * -1;
		} else {
			return n;
		}
	}
}