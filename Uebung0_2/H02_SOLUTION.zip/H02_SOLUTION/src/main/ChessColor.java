package main;

public enum ChessColor {
	BLACK, WHITE;
}