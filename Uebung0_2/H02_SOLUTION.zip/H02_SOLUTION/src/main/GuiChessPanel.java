package main;

import static fopbot.PaintUtils.*;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.LinkedList;

import javax.swing.UIManager;

import chesspieces.ChessPiece;
import fopbot.Block;
import fopbot.Coin;
import fopbot.FieldEntity;
import fopbot.GuiPanel;
import fopbot.KarelWorld;
import fopbot.Robot;
import fopbot.Wall;
import fopbot.World;

@SuppressWarnings("serial")
public class GuiChessPanel extends GuiPanel {

	private String infoMessage = "Info";
	private ChessColor activePlayer = ChessColor.WHITE;
	private ChessPiece pieceSelected = null;
	private Color[][] fieldColors;

	private Color fieldColorBlack = Color.DARK_GRAY;
	private Color fieldColorWhite = Color.WHITE;
	private Color fieldColorMove = Color.GREEN;
	private Color fieldColorAttack = Color.RED;
	private Color fieldColorSelected = Color.YELLOW;

	public GuiChessPanel(KarelWorld world) {
		super(world);

		fieldColors = new Color[world.getWidth()][world.getHeight()];
		resetFieldColors();

		addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent me) {
				handleMousePressed(me);
			}
		});
	}

	protected void handleMousePressed(MouseEvent me) {
		Point posClicked = me.getPoint();

		if (getWidth() != getUnscaledSize().width || getHeight() != getUnscaledSize().height) {

		} else {

			int width = BOARD_OFFSET + FIELD_BORDER_THICKNESS;
			int height = BOARD_OFFSET + FIELD_BORDER_THICKNESS;

			for (int h = 0; h < world.getHeight(); h++) {
				for (int w = 0; w < world.getWidth(); w++) {

					if (posClicked.x >= width && posClicked.x <= width + FIELD_INNER_SIZE) {
						if (posClicked.y >= height && posClicked.y <= height + FIELD_INNER_SIZE) {
							int fieldX = w;
							int fieldY = Math.abs(h - world.getHeight() + 1);
							// System.out.println("Clicked on field: " + fieldX + " X " + fieldY);

							resetFieldColors();

							if (pieceSelected != null) {
								handlePieceSelected(fieldX, fieldY);
							} else {
								handleNothingSelected(fieldX, fieldY);
							}

						}

					}

					width += FIELD_BORDER_THICKNESS + FIELD_INNER_SIZE;
				}
				width = BOARD_OFFSET + FIELD_BORDER_THICKNESS;
				height += FIELD_BORDER_THICKNESS + FIELD_INNER_SIZE;
			}

		}

	}

	private void handleNothingSelected(int fieldX, int fieldY) {
		ChessPiece clicked = getPieceAtField(fieldX, fieldY);
		if (clicked != null && clicked.getColor() == activePlayer) {
			// nicht auf leeres feld geklickt und eigene figur angewählt -> mögliche
			// spielzüge anzeigen

			Point[] possibleMoveFields = clicked.getMoveFields();

			boolean movePossible = false;

			if (possibleMoveFields != null) {
				for (Point p : possibleMoveFields) {
					movePossible = true;
					setFieldColor(p.x, p.y, fieldColorMove);
				}
			}

			Point[] possibleAttackFields = clicked.getAttackFields();

			if (possibleAttackFields != null) {
				for (Point p : possibleAttackFields) {
					movePossible = true;
					setFieldColor(p.x, p.y, fieldColorAttack);
				}
			}

			if (movePossible) {
				pieceSelected = clicked;
				setFieldColor(fieldX, fieldY, fieldColorSelected);
				infoMessage = "Active player: " + activePlayer.toString() + ": first selection: "
						+ pieceSelected.getClass().toString().replace("class chesspieces.", "");
			} else {
				pieceSelected = null;
				infoMessage = "Active player: " + activePlayer.toString() + ": Nothing selected";
			}

			updateGui();

		}
	}

	private void handlePieceSelected(int fieldX, int fieldY) {
		ChessPiece clicked = getPieceAtField(fieldX, fieldY);
		if (clicked == null) {
			// auf leeres feld geklickt -> move oder abwählen

			Point[] possibleMoveFields = pieceSelected.getMoveFields();

			boolean moved = false;

			if (possibleMoveFields != null) {
				for (Point p : possibleMoveFields) {
					if (p.x == fieldX && p.y == fieldY) {
						// verschiebe figur sofern gefunden
						pieceSelected.setField(fieldX, fieldY);
						moved = true;
					}
				}
			}

			if (moved) {
				// spieler wechseln usw
				activePlayer = CUtils.getOtherColor(activePlayer);
			}

			// abwählen
			pieceSelected = null;

			infoMessage = "Active player: " + activePlayer.toString() + ": Nothing selected";

			updateGui();
		} else {
			// figur angeklickt -> attackieren, oder ausgewählte figur wechseln
			if (clicked.getColor() != activePlayer) {
				// angeklickte figur hat andere farbe, daher attack überprüfen
				Point[] possibleAttackFields = pieceSelected.getAttackFields();
				boolean attacked = false;

				if (possibleAttackFields != null) {
					for (Point p : possibleAttackFields) {
						if (p.x == fieldX && p.y == fieldY) {
							clicked.turnOff();
							pieceSelected.setField(fieldX, fieldY);
							attacked = true;
						}
					}
				}

				if (attacked) {
					// spieler wechseln usw
					activePlayer = CUtils.getOtherColor(activePlayer);
					pieceSelected = null;
				} else {
					pieceSelected = null;
				}

				infoMessage = "Active player: " + activePlayer.toString() + ": Nothing selected";

				updateGui();
			} else {
				// figur wechseln

				Point[] possibleMoveFields = clicked.getMoveFields();

				boolean movePossible = false;

				if (possibleMoveFields != null) {
					for (Point p : possibleMoveFields) {
						movePossible = true;
						setFieldColor(p.x, p.y, fieldColorMove);
					}
				}

				Point[] possibleAttackFields = clicked.getAttackFields();

				if (possibleAttackFields != null) {
					for (Point p : possibleAttackFields) {
						movePossible = true;
						setFieldColor(p.x, p.y, fieldColorAttack);
					}
				}

				if (movePossible) {
					pieceSelected = clicked;
					setFieldColor(fieldX, fieldY, fieldColorSelected);
					infoMessage = "Active player: " + activePlayer.toString() + ": Changed selection to: "
							+ pieceSelected.getClass().toString().replace("class chesspieces.", "");
				} else {
					pieceSelected = null;
					infoMessage = "Active player: " + activePlayer.toString() + ": Nothing selected";
				}

				updateGui();

			}
		}
	}

	private ChessPiece getPieceAtField(int x, int y) {
		LinkedList<FieldEntity> entities = world.getAllFieldEntities();
		for (FieldEntity ce : entities) {
			if (ce instanceof ChessPiece) {
				if (((ChessPiece) ce).isTurnedOn() && ce.getX() == x && ce.getY() == y) {
					return (ChessPiece) ce;
				}
			}
		}
		return null;
	}

	private void setFieldColor(int x, int y, Color c) {
		int y_m = Math.abs(y - World.getHeight() + 1);
		fieldColors[x][y_m] = c;
	}

	private void resetFieldColors() {
		for (int h = 0; h < world.getHeight(); h++) {
			for (int w = 0; w < world.getWidth(); w++) {
				if (w % 2 != h % 2) {
					fieldColors[w][h] = fieldColorBlack;
				} else {
					fieldColors[w][h] = fieldColorWhite;
				}
			}
		}
	}

	@Override
	public void paintComponent(Graphics g) {
		Image image = new BufferedImage(getUnscaledSize().width, getUnscaledSize().height, BufferedImage.TYPE_INT_ARGB);
		Graphics gImage = image.getGraphics();

		// clear image
		Color backupColor = gImage.getColor();
		Color bgColor = UIManager.getColor("Panel.background");
		gImage.setColor(bgColor);
		gImage.fillRect(0, 0, getUnscaledSize().width, getUnscaledSize().height);
		gImage.setColor(backupColor);

		draw(gImage);

		if (getWidth() != getUnscaledSize().width || getHeight() != getUnscaledSize().height) {
			image = image.getScaledInstance(getWidth(), getHeight(), Image.SCALE_SMOOTH);
		}

		g.drawImage(image, 0, 0, null);
	}

	protected void draw(Graphics g) {
		g.setColor(Color.BLACK);
		g.drawString(infoMessage, BOARD_OFFSET + 1, 15);
		drawBoard(g);

		LinkedList<FieldEntity> entities = world.getAllFieldEntities();
		LinkedList<Robot> robots = new LinkedList<Robot>();
		for (FieldEntity ce : entities) {
			if (ce instanceof Robot) {
				// collect robots, so they can be drawn last
				// robots are always on top of every other field object
				robots.add((Robot) ce);
				continue;
			}

			if (ce instanceof Coin) {
				drawCoin((Coin) ce, g);
				continue;
			}

			if (ce instanceof Block) {
				drawBlock((Block) ce, g);
				continue;
			}

			if (ce instanceof Wall) {
				drawWall((Wall) ce, g);
				continue;
			}

			System.err.println("Could not draw FieldEntity of Type: " + ce.getClass().getName());
		}

		// draw robots last
		for (Robot r : robots) {
			if (r.isTurnedOn()) {
				drawRobot(r, g);
			}
		}

	}

	protected void drawBoard(Graphics g) {
		int width = 0;
		int height = 0;
		// draw outer borders
		width = BOARD_OFFSET;
		height = BOARD_OFFSET;
		g.setColor(Color.GRAY);
		Point p = getBoardSize(world);
		g.fillRect(width, height, p.x, p.y);

		// draw inner borders
		width = BOARD_OFFSET + FIELD_BORDER_THICKNESS;
		height = BOARD_OFFSET + FIELD_BORDER_THICKNESS;
		g.setColor(Color.GRAY);
		g.fillRect(width, height, p.x - FIELD_BORDER_THICKNESS * 2, p.y - FIELD_BORDER_THICKNESS * 2);

		// draw fields
		width = BOARD_OFFSET + FIELD_BORDER_THICKNESS;
		height = BOARD_OFFSET + FIELD_BORDER_THICKNESS;
		g.setColor(Color.LIGHT_GRAY);
		for (int h = 0; h < world.getHeight(); h++) {
			for (int w = 0; w < world.getWidth(); w++) {
				g.setColor(fieldColors[w][h]);
				g.fillRect(width, height, FIELD_INNER_SIZE, FIELD_INNER_SIZE);

				// g.setColor(Color.RED);
				// g.drawString(w + ";" + (h - 7) * -1, width, height);
				// g.setColor(Color.LIGHT_GRAY);

				width += FIELD_BORDER_THICKNESS + FIELD_INNER_SIZE;
			}
			width = BOARD_OFFSET + FIELD_BORDER_THICKNESS;
			height += FIELD_BORDER_THICKNESS + FIELD_INNER_SIZE;
		}

	}

}