package main;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.awt.Point;
import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;

import chesspieces.Bishop;
import chesspieces.ChessPiece;
import chesspieces.King;
import chesspieces.Knight;
import chesspieces.Pawn;
import chesspieces.Queen;
import chesspieces.Rook;
import fopbot.World;

public class H02_Tests {

	private void resetWorld() {
		World.reset();
		World.setSize(8, 8);
		World.setDelay(0);
		ChessBoard.initChessPieces();
	}

	@Test
	public void initalBoardTest() {
		resetWorld();
		ChessPiece[] all = ChessBoard.getAllChessPieces();

		// if no piece has moved yet, not a single piece should be able to attack
		for (ChessPiece p : all) {
			assertNull(p.getAttackFields());
		}

		// if piece is not a pawn and not a knight, it should not be able to move
		// forward because all paths are blocked by pawns
		for (ChessPiece p : all) {
			if (p instanceof Pawn || p instanceof Knight) {
				continue;
			}
			assertNull(p.getMoveFields());
		}
	}

	static class PointComparator implements Comparator<Point> {
		public int compare(Point c1, Point c2) {
			int cmp1 = c1.x;
			int cmp2 = c2.x;

			if (cmp1 == cmp2) {
				cmp1 = c1.y;
				cmp2 = c2.y;
			}

			if (cmp1 == cmp2) {
				return 0;
			} else {
				if (cmp1 < cmp2) {
					return -1;
				} else {
					return 1;
				}
			}

		}
	}

	@Test
	public void H1_Pawn_2forward_notBlocked() {
		resetWorld();
		ChessPiece[] all = ChessBoard.getAllChessPieces();
		Pawn[] pawns = Arrays.stream(all).filter(x -> x instanceof Pawn).collect(Collectors.toList())
				.toArray(new Pawn[1]);

		// if path is not blocked and pawn is at inital position, it can move 2 steps
		for (Pawn p : pawns) {
			assertNull(p.getAttackFields());
			Point[] mf = p.getMoveFields();
			Arrays.sort(mf, new PointComparator());
			if (p.getColor() == ChessColor.BLACK) {
				// oben
				Point[] validMoves = { new Point(p.getX(), p.getY() - 1), new Point(p.getX(), p.getY() - 2) };
				Arrays.sort(validMoves, new PointComparator());
				assertArrayEquals(validMoves, mf);
			} else {
				Point[] validMoves = { new Point(p.getX(), p.getY() + 1), new Point(p.getX(), p.getY() + 2) };
				Arrays.sort(validMoves, new PointComparator());
				assertArrayEquals(validMoves, mf);
			}
		}
	}

	@Test
	public void H1_Pawn_2forward_blocked() {
		resetWorld();
		ChessPiece[] all = ChessBoard.getAllChessPieces();

		Pawn[] pawns = Arrays.stream(all).filter(x -> x instanceof Pawn).collect(Collectors.toList())
				.toArray(new Pawn[1]);

		// block fields that are 2 steps away from all pawns -> pawns can only go one
		// field forward
		for (ChessPiece p : all) {
			if (p instanceof Pawn) {
				continue;
			}

			if (p.getColor() == ChessColor.BLACK) {
				p.setY(3);
			} else {
				p.setY(4);
			}
		}

		for (Pawn p : pawns) {
			assertNull(p.getAttackFields());
			Point[] mf = p.getMoveFields();
			Arrays.sort(mf, new PointComparator());
			if (p.getColor() == ChessColor.BLACK) {
				// oben
				Point[] validMoves = { new Point(p.getX(), p.getY() - 1) };
				Arrays.sort(validMoves, new PointComparator());
				assertArrayEquals(validMoves, mf);
			} else {
				Point[] validMoves = { new Point(p.getX(), p.getY() + 1) };
				Arrays.sort(validMoves, new PointComparator());
				assertArrayEquals(validMoves, mf);
			}
		}
	}

	@Test
	public void H1_Pawn_1forward_blocked() {
		resetWorld();
		ChessPiece[] all = ChessBoard.getAllChessPieces();
		Pawn[] pawns = Arrays.stream(all).filter(x -> x instanceof Pawn).collect(Collectors.toList())
				.toArray(new Pawn[1]);

		// block fields that are 2 steps away from all pawns -> pawns can only go one
		// field forward
		for (ChessPiece p : all) {
			if (p instanceof Pawn) {
				continue;
			}

			if (p.getColor() == ChessColor.BLACK) {
				p.setY(2);
			} else {
				p.setY(5);
			}
		}

		for (Pawn p : pawns) {
			assertNull(p.getMoveFields());
		}
	}

	@Test
	public void H1_Pawn_attack1() {
		resetWorld();
		ChessPiece[] all = ChessBoard.getAllChessPieces();
		Pawn[] pawns = Arrays.stream(all).filter(x -> x instanceof Pawn).collect(Collectors.toList())
				.toArray(new Pawn[1]);

		// block fields that are 2 steps away from all pawns -> pawns can only go one
		// field forward
		for (ChessPiece p : all) {
			if (p instanceof Pawn) {
				continue;
			}

			if (p.getColor() == ChessColor.BLACK) {
				p.setY(2);
			} else {
				p.setY(5);
			}
		}

		for (Pawn p : pawns) {
			Point[] af = p.getAttackFields();
			Arrays.sort(af, new PointComparator());
			if (p.getColor() == ChessColor.BLACK) {
				// oben
				Point[] validAttacks = { new Point(p.getX() + 1, p.getY() - 1), new Point(p.getX() - 1, p.getY() - 1) };
				if (p.getX() == 0) {
					validAttacks = new Point[1];
					validAttacks[0] = new Point(p.getX() + 1, p.getY() - 1);
				}

				if (p.getX() == 7) {
					validAttacks = new Point[1];
					validAttacks[0] = new Point(p.getX() - 1, p.getY() - 1);
				}

				Arrays.sort(validAttacks, new PointComparator());
				assertArrayEquals(validAttacks, af);
			} else {
				Point[] validAttacks = { new Point(p.getX() + 1, p.getY() + 1), new Point(p.getX() - 1, p.getY() + 1) };

				if (p.getX() == 0) {
					validAttacks = new Point[1];
					validAttacks[0] = new Point(p.getX() + 1, p.getY() + 1);
				}

				if (p.getX() == 7) {
					validAttacks = new Point[1];
					validAttacks[0] = new Point(p.getX() - 1, p.getY() + 1);
				}

				Arrays.sort(validAttacks, new PointComparator());
				assertArrayEquals(validAttacks, af);
			}
		}
	}

	@Test
	public void H1_Pawn_attack2() {
		resetWorld();

		Pawn pWhite = (Pawn) getChessPieceAtPosition(3, 1);
		Pawn pBlack = (Pawn) getChessPieceAtPosition(3, 6);
		Rook rWhite = (Rook) getChessPieceAtPosition(0, 0);
		Rook rBlack = (Rook) getChessPieceAtPosition(0, 7);

		rWhite.setField(4, 4);
		rBlack.setField(4, 3);

		pBlack.setField(3, 5);
		Point[] af = pBlack.getAttackFields();
		Arrays.sort(af, new PointComparator());
		Point[] validAttacks = { new Point(rWhite.getX(), rWhite.getY()) };
		Arrays.sort(validAttacks, new PointComparator());
		assertArrayEquals(validAttacks, af);

		pBlack.setField(5, 5);
		af = pBlack.getAttackFields();
		Arrays.sort(af, new PointComparator());
		validAttacks[0] = new Point(rWhite.getX(), rWhite.getY());
		Arrays.sort(validAttacks, new PointComparator());
		assertArrayEquals(validAttacks, af);

		pWhite.setField(3, 2);
		af = pWhite.getAttackFields();
		Arrays.sort(af, new PointComparator());
		validAttacks[0] = new Point(rBlack.getX(), rBlack.getY());
		Arrays.sort(validAttacks, new PointComparator());
		assertArrayEquals(validAttacks, af);

		pWhite.setField(5, 2);
		af = pWhite.getAttackFields();
		Arrays.sort(af, new PointComparator());
		validAttacks[0] = new Point(rBlack.getX(), rBlack.getY());
		Arrays.sort(validAttacks, new PointComparator());
		assertArrayEquals(validAttacks, af);

	}

	@Test
	public void H2_Rook() {
		resetWorld();

		Rook rWhite = (Rook) getChessPieceAtPosition(0, 0);
		Rook rBlack = (Rook) getChessPieceAtPosition(0, 7);

		rWhite.setField(4, 4);
		rBlack.setField(2, 4);
		Point[] af = rWhite.getAttackFields();
		Arrays.sort(af, new PointComparator());
		Point[] mf = rWhite.getMoveFields();
		Arrays.sort(mf, new PointComparator());

		Point[] validMoves = { new Point(4, 2), new Point(4, 3), new Point(4, 5), new Point(3, 4), new Point(5, 4),
				new Point(6, 4), new Point(7, 4) };
		Arrays.sort(validMoves, new PointComparator());
		assertArrayEquals(validMoves, mf);

		Point[] validAttacks = { new Point(4, 6), new Point(2, 4) };
		Arrays.sort(validAttacks, new PointComparator());
		assertArrayEquals(validAttacks, af);

		rBlack.setField(3, 4);
		rWhite.setField(5, 4);
		Point[] af2 = rBlack.getAttackFields();
		Arrays.sort(af2, new PointComparator());
		Point[] mf2 = rBlack.getMoveFields();
		Arrays.sort(mf2, new PointComparator());

		Point[] validMoves2 = { new Point(3, 5), new Point(3, 3), new Point(3, 2), new Point(0, 4), new Point(1, 4),
				new Point(2, 4), new Point(4, 4) };
		Arrays.sort(validMoves2, new PointComparator());
		assertArrayEquals(validMoves2, mf2);

		Point[] validAttacks2 = { new Point(3, 1), new Point(5, 4) };
		Arrays.sort(validAttacks2, new PointComparator());
		assertArrayEquals(validAttacks2, af2);
	}

	@Test
	public void H3_Bishop() {
		resetWorld();

		Bishop bWhite = (Bishop) getChessPieceAtPosition(2, 0);
		Bishop bBlack = (Bishop) getChessPieceAtPosition(2, 7);

		bWhite.setField(4, 4);
		bBlack.setField(3, 3);
		Point[] af = bWhite.getAttackFields();
		Arrays.sort(af, new PointComparator());
		Point[] mf = bWhite.getMoveFields();
		Arrays.sort(mf, new PointComparator());

		Point[] validMoves = { new Point(3, 5), new Point(5, 5), new Point(5, 3), new Point(6, 2) };
		Arrays.sort(validMoves, new PointComparator());
		assertArrayEquals(validMoves, mf);

		Point[] validAttacks = { new Point(3, 3), new Point(6, 6), new Point(2, 6) };
		Arrays.sort(validAttacks, new PointComparator());
		assertArrayEquals(validAttacks, af);

		bBlack.setField(5, 5);
		bWhite.setField(2, 2);

		Point[] af2 = bBlack.getAttackFields();
		Arrays.sort(af2, new PointComparator());
		Point[] mf2 = bBlack.getMoveFields();
		Arrays.sort(mf2, new PointComparator());

		Point[] validMoves2 = { new Point(4, 4), new Point(3, 3), new Point(6, 4), new Point(7, 3) };
		Arrays.sort(validMoves2, new PointComparator());
		assertArrayEquals(validMoves2, mf2);

		Point[] validAttacks2 = { new Point(2, 2) };
		Arrays.sort(validAttacks2, new PointComparator());
		assertArrayEquals(validAttacks2, af2);
	}

	@Test
	public void H4_Queen() {
		resetWorld();

		Queen qWhite = (Queen) getChessPieceAtPosition(3, 0);
		Queen qBlack = (Queen) getChessPieceAtPosition(3, 7);

		qWhite.setField(4, 4);
		qBlack.setField(3, 3);
		Point[] af = qWhite.getAttackFields();
		Arrays.sort(af, new PointComparator());
		Point[] mf = qWhite.getMoveFields();
		Arrays.sort(mf, new PointComparator());

		Point[] validMoves = { new Point(0, 4), new Point(1, 4), new Point(2, 4), new Point(3, 4), new Point(5, 4),
				new Point(6, 4), new Point(7, 4), new Point(4, 3), new Point(4, 2), new Point(4, 5), new Point(3, 5),
				new Point(5, 5), new Point(5, 3), new Point(6, 2) };
		Arrays.sort(validMoves, new PointComparator());
		assertArrayEquals(validMoves, mf);

		Point[] validAttacks = { new Point(3, 3), new Point(6, 6), new Point(2, 6), new Point(4, 6) };
		Arrays.sort(validAttacks, new PointComparator());
		assertArrayEquals(validAttacks, af);

		qBlack.setField(5, 5);
		qWhite.setField(2, 2);

		Point[] af2 = qBlack.getAttackFields();
		Arrays.sort(af2, new PointComparator());
		Point[] mf2 = qBlack.getMoveFields();
		Arrays.sort(mf2, new PointComparator());

		Point[] validMoves2 = { new Point(0, 5), new Point(1, 5), new Point(2, 5), new Point(3, 5), new Point(4, 5),
				new Point(6, 5), new Point(7, 5), new Point(5, 4), new Point(5, 3), new Point(5, 2), new Point(4, 4),
				new Point(3, 3), new Point(6, 4), new Point(7, 3) };
		Arrays.sort(validMoves2, new PointComparator());
		assertArrayEquals(validMoves2, mf2);

		Point[] validAttacks2 = { new Point(2, 2), new Point(5, 1) };
		Arrays.sort(validAttacks2, new PointComparator());
		assertArrayEquals(validAttacks2, af2);
	}

	@Test
	public void H5_King() {
		resetWorld();

		King kWhite = (King) getChessPieceAtPosition(4, 0);
		King kBlack = (King) getChessPieceAtPosition(4, 7);

		kWhite.setField(3, 5);
		Point[] af = kWhite.getAttackFields();
		Arrays.sort(af, new PointComparator());
		Point[] mf = kWhite.getMoveFields();
		Arrays.sort(mf, new PointComparator());

		Point[] validMoves = { new Point(2, 5), new Point(4, 5), new Point(2, 4), new Point(3, 4), new Point(4, 4) };
		Arrays.sort(validMoves, new PointComparator());
		assertArrayEquals(validMoves, mf);

		Point[] validAttacks = { new Point(2, 6), new Point(3, 6), new Point(4, 6) };
		Arrays.sort(validAttacks, new PointComparator());
		assertArrayEquals(validAttacks, af);

		kBlack.setField(4, 4);

		Point[] af2 = kBlack.getAttackFields();
		Arrays.sort(af2, new PointComparator());
		Point[] mf2 = kBlack.getMoveFields();
		Arrays.sort(mf2, new PointComparator());

		Point[] validMoves2 = { new Point(4, 5), new Point(5, 5), new Point(5, 4), new Point(5, 3), new Point(4, 3),
				new Point(3, 3), new Point(3, 4) };
		Arrays.sort(validMoves2, new PointComparator());
		assertArrayEquals(validMoves2, mf2);

		Point[] validAttacks2 = { new Point(3, 5) };
		Arrays.sort(validAttacks2, new PointComparator());
		assertArrayEquals(validAttacks2, af2);
	}

	@Test
	public void H6_Knight() {
		resetWorld();

		Knight kWhite = (Knight) getChessPieceAtPosition(6, 0);
		Knight kBlack = (Knight) getChessPieceAtPosition(6, 7);

		kWhite.setField(3, 5);

		Point[] af = kWhite.getAttackFields();
		Arrays.sort(af, new PointComparator());
		Point[] mf = kWhite.getMoveFields();
		Arrays.sort(mf, new PointComparator());

		Point[] validMoves = { new Point(1, 4), new Point(2, 3), new Point(4, 3), new Point(5, 4) };
		Arrays.sort(validMoves, new PointComparator());
		assertArrayEquals(validMoves, mf);

		Point[] validAttacks = { new Point(4, 7), new Point(2, 7), new Point(1, 6), new Point(5, 6) };
		Arrays.sort(validAttacks, new PointComparator());
		assertArrayEquals(validAttacks, af);

		kBlack.setField(4, 4);

		Point[] af2 = kBlack.getAttackFields();
		assertNull(af2);
		Point[] mf2 = kBlack.getMoveFields();
		Arrays.sort(mf2, new PointComparator());

		Point[] validMoves2 = { new Point(2, 5), new Point(6, 5), new Point(2, 3), new Point(3, 2), new Point(5, 2),
				new Point(6, 3) };
		Arrays.sort(validMoves2, new PointComparator());
		assertArrayEquals(validMoves2, mf2);

	}

	private ChessPiece getChessPieceAtPosition(int x, int y) {
		ChessPiece[] all = ChessBoard.getAllChessPieces();
		for (ChessPiece p : all) {
			if (p.getX() == x && p.getY() == y) {
				return p;
			}
		}
		return null;
	}

	private void showFreeze() {
		World.getGlobalWorld().setGuiPanel(new GuiChessPanel(World.getGlobalWorld()));
		ChessBoard.loadChessImages();
		World.setVisible(true);
		while (true) {
			if (1 == 2)
				break;
			int i = 0;
			i++;
		}
	}

}
